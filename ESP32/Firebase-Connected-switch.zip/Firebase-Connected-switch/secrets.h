/* 1. Define the WiFi credentials */
#define WIFI_SSID "ECALEVENT"
#define WIFI_PASSWORD "garamond"

// For the following credentials, see examples/Authentications/SignInAsUser/EmailPassword/EmailPassword.ino

/* 2. Define the API Key */
#define API_KEY "AIzaSyC1UkPW0wY57nAoKTx6TNhC941eB9PgRmQ"

/* 3. Define the RTDB URL */
#define DATABASE_URL "https://keyboard-eb76e-default-rtdb.europe-west1.firebasedatabase.app"  //<databaseName>.firebaseio.com or <databaseName>.<region>.firebasedatabase.app

/* 4. Define the user Email and password that alreadey registerd or added in your project */
#define USER_EMAIL "elina.crespi@ecal.ch"
#define USER_PASSWORD "ecalmid"
