#define WIFI_SSID "ECALEVENT"
#define WIFI_PASS "garamond"
// autre wifi
//#define WIFI_SSID "xx"
//#define WIFI_PASS "xx/"
